import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:todo_flutter/controller/lista_todo_controller.dart';
import 'package:todo_flutter/repositories/todo_repo.dart';

import 'models/todo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var repo = TodoRepo();
  List<Todo> todos = [];
  final todoController = TextEditingController();
  final listaTodosController = ListaTodoController();

  @override
  void initState() {
    listaTodosController.pegarTodo();
    super.initState();
  }

  // pegarTodo() async {
  //   try {
  //     todos = await repo.getTodo();
  //     setState(() {});
  //   } catch (e) {
  //     print('Erro ao carregar todos: $e');
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.blue,
            Colors.green,
          ], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 50),
              TextField(
                controller: todoController,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Adicionar uma tarefa',
                  hintStyle: TextStyle(color: Colors.white),
                  filled: true,
                  fillColor: Colors.white24,
                  prefixIcon: Icon(Icons.add, color: Colors.white),
                  suffixIcon: Icon(Icons.send, color: Colors.white),
                  contentPadding: EdgeInsets.all(20),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    borderSide: BorderSide(color: Colors.white),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                ),
              ),
              const SizedBox(height: 100),
              Expanded(
                child: SizedBox(
                  height: double.infinity,
                  child: Obx(() => ListView.separated(
                        separatorBuilder: (context, index) => const Divider(),
                        itemCount: listaTodosController.todosList.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onLongPress: () {
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                        title: const Text('Atenção'),
                                        content: const Text('Tem certeza que deseja apagar esta tarefa?'),
                                        actions: [
                                          TextButton(
                                            child: const Text('Cancelar'),
                                            onPressed: () {
                                              Navigator.of(context).pop(); // Fecha o alerta sem apagar o item
                                            },
                                          ),
                                          TextButton(
                                            child: const Text('Apagar'),
                                            onPressed: () {
                                              repo.apagarTodo(todos[index].objectId);
                                              // pegarTodo();
                                              setState(() {});
                                              Navigator.of(context).pop();
                                            },
                                          )
                                        ]);
                                  });
                            },
                            child: ListTile(
                              leading: const Text(
                                '🤐',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 20,
                                ),
                              ),
                              title: Text(
                                listaTodosController.todosList[index].description,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                          );
                        },
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          child: const Text('+'),
          onPressed: () {
            listaTodosController.addTodo(Todo(
              name: 'name',
              description: todoController.text,
              title: 'title',
            ));
            todoController.text = '';
            // pegarTodo();
            setState(() {});
          }),
    );
  }
}
